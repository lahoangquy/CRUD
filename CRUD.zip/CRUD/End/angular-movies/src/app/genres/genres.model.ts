export interface genreCreationDTO {
    name: string;
}

export interface genreDTO {
    id: number;
    name: string;
}