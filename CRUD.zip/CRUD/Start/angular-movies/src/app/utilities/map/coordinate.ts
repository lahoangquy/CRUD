export interface coordinatesMap {
    latitude: number;
    longitude: number;
}