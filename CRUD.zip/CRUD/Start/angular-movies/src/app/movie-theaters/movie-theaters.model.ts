export interface movieTheatersCreationDTO{
    name: string;
    latitude: number;
    longitude: number;
} 

export interface movieTheatersDTO{
    name: string;
    latitude: number;
    longitude: number;
} 